import * as THREE from 'three';

/**
 * Planet type definitions based on design doc
 * Each type has distinct visuals and gameplay characteristics
 */
export const PLANET_TYPES = {
    terran: {
        name: 'Terran',
        description: 'Earth-like world with water and vegetation',
        baseColor: 0x4488aa,
        secondaryColor: 0x228844,
        size: [1.2, 2.0],
        habitability: [60, 95],
        metals: [20, 50],
        textureStyle: 'continental'
    },
    desert: {
        name: 'Desert',
        description: 'Arid rocky world with valuable mineral deposits',
        baseColor: 0xcc8844,
        secondaryColor: 0xaa6622,
        size: [1.0, 1.8],
        habitability: [10, 35],
        metals: [50, 85],
        textureStyle: 'rocky'
    },
    jungle: {
        name: 'Jungle',
        description: 'Dense vegetation covers this humid world',
        baseColor: 0x44aa44,
        secondaryColor: 0x226622,
        size: [1.3, 2.2],
        habitability: [50, 80],
        metals: [25, 45],
        textureStyle: 'continental'
    },
    ice: {
        name: 'Ice',
        description: 'Frozen world with rare element deposits',
        baseColor: 0xaaddff,
        secondaryColor: 0x88bbee,
        size: [0.9, 1.6],
        habitability: [5, 25],
        metals: [15, 40],
        textureStyle: 'frozen'
    },
    ocean: {
        name: 'Ocean',
        description: 'Water world with scattered island chains',
        baseColor: 0x2266aa,
        secondaryColor: 0x44aacc,
        size: [1.4, 2.4],
        habitability: [55, 85],
        metals: [5, 25],
        textureStyle: 'ocean'
    },
    lava: {
        name: 'Lava',
        description: 'Volcanic world with extreme metal richness',
        baseColor: 0xcc4422,
        secondaryColor: 0xff6600,
        size: [1.0, 1.7],
        habitability: [0, 10],
        metals: [75, 100],
        textureStyle: 'volcanic'
    },
    gasGiant: {
        name: 'Gas Giant',
        description: 'Massive gas world - moons may be habitable',
        baseColor: 0xddaa77,
        secondaryColor: 0xcc8855,
        size: [3.5, 6.0],
        habitability: [0, 0],
        metals: [0, 0],
        textureStyle: 'banded'
    },
    iceGiant: {
        name: 'Ice Giant',
        description: 'Cold gas giant with icy atmosphere',
        baseColor: 0x6699cc,
        secondaryColor: 0x4477aa,
        size: [2.8, 4.5],
        habitability: [0, 0],
        metals: [0, 0],
        textureStyle: 'banded'
    },
    barren: {
        name: 'Barren',
        description: 'Lifeless rock with moderate resources',
        baseColor: 0x888888,
        secondaryColor: 0x666666,
        size: [0.6, 1.2],
        habitability: [0, 5],
        metals: [30, 60],
        textureStyle: 'rocky'
    }
};

/**
 * Creates a procedurally generated planet texture based on type
 * @param {string} textureStyle - Style of texture (continental, rocky, frozen, ocean, volcanic, banded)
 * @param {number} baseColor - Base color in hex format
 * @param {number} secondaryColor - Secondary color for variation
 * @param {number} resolution - Texture resolution (default: 512)
 * @returns {THREE.CanvasTexture}
 */
export function createPlanetTexture(textureStyle, baseColor, secondaryColor, resolution = 512) {
    const canvas = document.createElement('canvas');
    canvas.width = resolution;
    canvas.height = resolution;
    const ctx = canvas.getContext('2d');

    const baseR = (baseColor >> 16) & 0xff;
    const baseG = (baseColor >> 8) & 0xff;
    const baseB = baseColor & 0xff;

    const secR = (secondaryColor >> 16) & 0xff;
    const secG = (secondaryColor >> 8) & 0xff;
    const secB = secondaryColor & 0xff;

    // Base fill
    ctx.fillStyle = `rgb(${baseR}, ${baseG}, ${baseB})`;
    ctx.fillRect(0, 0, resolution, resolution);

    switch (textureStyle) {
        case 'continental':
            // Continents and oceans
            for (let i = 0; i < 8; i++) {
                const x = Math.random() * resolution;
                const y = Math.random() * resolution;
                const size = 60 + Math.random() * 120;
                ctx.fillStyle = `rgba(${secR}, ${secG}, ${secB}, 0.7)`;
                ctx.beginPath();
                // Irregular continent shape
                ctx.moveTo(x, y);
                for (let j = 0; j < 8; j++) {
                    const angle = (j / 8) * Math.PI * 2;
                    const dist = size * (0.5 + Math.random() * 0.5);
                    ctx.lineTo(x + Math.cos(angle) * dist, y + Math.sin(angle) * dist);
                }
                ctx.closePath();
                ctx.fill();
            }
            // Cloud wisps
            for (let i = 0; i < 20; i++) {
                const x = Math.random() * resolution;
                const y = Math.random() * resolution;
                ctx.fillStyle = `rgba(255, 255, 255, ${0.1 + Math.random() * 0.15})`;
                ctx.beginPath();
                ctx.ellipse(x, y, 20 + Math.random() * 40, 10 + Math.random() * 20, Math.random() * Math.PI, 0, Math.PI * 2);
                ctx.fill();
            }
            break;

        case 'rocky':
            // Craters and rocks
            for (let i = 0; i < 50; i++) {
                const x = Math.random() * resolution;
                const y = Math.random() * resolution;
                const size = 5 + Math.random() * 30;
                const brightness = Math.random() > 0.5 ? 40 : -40;
                ctx.fillStyle = `rgba(${baseR + brightness}, ${baseG + brightness}, ${baseB + brightness}, 0.6)`;
                ctx.beginPath();
                ctx.arc(x, y, size, 0, Math.PI * 2);
                ctx.fill();
            }
            // Ridges
            for (let i = 0; i < 10; i++) {
                ctx.strokeStyle = `rgba(${secR}, ${secG}, ${secB}, 0.4)`;
                ctx.lineWidth = 2 + Math.random() * 4;
                ctx.beginPath();
                ctx.moveTo(Math.random() * resolution, Math.random() * resolution);
                ctx.lineTo(Math.random() * resolution, Math.random() * resolution);
                ctx.stroke();
            }
            break;

        case 'frozen':
            // Ice cracks
            ctx.strokeStyle = `rgba(255, 255, 255, 0.5)`;
            for (let i = 0; i < 15; i++) {
                ctx.lineWidth = 1 + Math.random() * 3;
                ctx.beginPath();
                let x = Math.random() * resolution;
                let y = Math.random() * resolution;
                ctx.moveTo(x, y);
                for (let j = 0; j < 5; j++) {
                    x += (Math.random() - 0.5) * 80;
                    y += (Math.random() - 0.5) * 80;
                    ctx.lineTo(x, y);
                }
                ctx.stroke();
            }
            // Snow patches
            for (let i = 0; i < 30; i++) {
                ctx.fillStyle = `rgba(255, 255, 255, ${0.2 + Math.random() * 0.3})`;
                ctx.beginPath();
                ctx.arc(Math.random() * resolution, Math.random() * resolution, 10 + Math.random() * 40, 0, Math.PI * 2);
                ctx.fill();
            }
            break;

        case 'ocean':
            // Wave patterns
            for (let y = 0; y < resolution; y += 20) {
                ctx.strokeStyle = `rgba(${secR}, ${secG}, ${secB}, 0.3)`;
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(0, y + Math.sin(y * 0.1) * 10);
                for (let x = 0; x < resolution; x += 10) {
                    ctx.lineTo(x, y + Math.sin((x + y) * 0.05) * 8);
                }
                ctx.stroke();
            }
            // Islands
            for (let i = 0; i < 5; i++) {
                ctx.fillStyle = `rgba(100, 150, 80, 0.7)`;
                ctx.beginPath();
                ctx.arc(Math.random() * resolution, Math.random() * resolution, 5 + Math.random() * 15, 0, Math.PI * 2);
                ctx.fill();
            }
            break;

        case 'volcanic':
            // Lava flows
            for (let i = 0; i < 12; i++) {
                const gradient = ctx.createLinearGradient(
                    Math.random() * resolution, Math.random() * resolution,
                    Math.random() * resolution, Math.random() * resolution
                );
                gradient.addColorStop(0, `rgba(255, 100, 0, 0.8)`);
                gradient.addColorStop(0.5, `rgba(255, 200, 0, 0.6)`);
                gradient.addColorStop(1, `rgba(200, 50, 0, 0.4)`);
                ctx.strokeStyle = gradient;
                ctx.lineWidth = 3 + Math.random() * 8;
                ctx.beginPath();
                let x = Math.random() * resolution;
                let y = Math.random() * resolution;
                ctx.moveTo(x, y);
                for (let j = 0; j < 6; j++) {
                    x += (Math.random() - 0.5) * 100;
                    y += (Math.random() - 0.5) * 100;
                    ctx.lineTo(x, y);
                }
                ctx.stroke();
            }
            // Dark rock
            for (let i = 0; i < 30; i++) {
                ctx.fillStyle = `rgba(30, 20, 20, 0.5)`;
                ctx.beginPath();
                ctx.arc(Math.random() * resolution, Math.random() * resolution, 10 + Math.random() * 30, 0, Math.PI * 2);
                ctx.fill();
            }
            break;

        case 'banded':
            // Gas giant bands
            const numBands = 12 + Math.floor(Math.random() * 8);
            for (let i = 0; i < numBands; i++) {
                const y = (i / numBands) * resolution;
                const height = resolution / numBands;
                const variation = Math.random() * 40 - 20;
                ctx.fillStyle = `rgb(${Math.max(0, Math.min(255, baseR + variation))}, ${Math.max(0, Math.min(255, baseG + variation))}, ${Math.max(0, Math.min(255, baseB + variation))})`;
                ctx.fillRect(0, y, resolution, height);
            }
            // Storm spots
            for (let i = 0; i < 3; i++) {
                const x = Math.random() * resolution;
                const y = Math.random() * resolution;
                ctx.fillStyle = `rgba(${secR}, ${secG}, ${secB}, 0.8)`;
                ctx.beginPath();
                ctx.ellipse(x, y, 15 + Math.random() * 30, 10 + Math.random() * 15, 0, 0, Math.PI * 2);
                ctx.fill();
            }
            break;
    }

    // Add spherical shading overlay
    const gradient = ctx.createRadialGradient(
        resolution * 0.35, resolution * 0.35, 0,
        resolution * 0.5, resolution * 0.5, resolution * 0.6
    );
    gradient.addColorStop(0, 'rgba(255, 255, 255, 0.2)');
    gradient.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
    gradient.addColorStop(0.8, 'rgba(0, 0, 0, 0.2)');
    gradient.addColorStop(1, 'rgba(0, 0, 0, 0.4)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, resolution, resolution);

    return new THREE.CanvasTexture(canvas);
}

/**
 * Creates ring geometry for ringed planets
 * @param {number} innerRadius - Inner ring radius
 * @param {number} outerRadius - Outer ring radius
 * @param {number} color - Ring color
 * @returns {THREE.Mesh}
 */
export function createPlanetRings(innerRadius, outerRadius, color) {
    const geometry = new THREE.RingGeometry(innerRadius, outerRadius, 64);

    // Create ring texture
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');

    const r = (color >> 16) & 0xff;
    const g = (color >> 8) & 0xff;
    const b = color & 0xff;

    // Multiple ring bands
    for (let x = 0; x < 256; x++) {
        const opacity = 0.3 + Math.sin(x * 0.1) * 0.2 + Math.random() * 0.1;
        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${opacity})`;
        ctx.fillRect(x, 0, 1, 64);
    }

    const texture = new THREE.CanvasTexture(canvas);

    const material = new THREE.MeshBasicMaterial({
        map: texture,
        transparent: true,
        opacity: 0.8,
        side: THREE.DoubleSide
    });

    const rings = new THREE.Mesh(geometry, material);
    rings.rotation.x = Math.PI / 2 + (Math.random() - 0.5) * 0.3; // Slight tilt

    return rings;
}

/**
 * Generates random planet attributes within type ranges
 * @param {Object} planetType - Planet type definition
 * @returns {Object} Generated attributes
 */
export function generatePlanetAttributes(planetType) {
    const size = planetType.size[0] + Math.random() * (planetType.size[1] - planetType.size[0]);
    const habitability = Math.floor(planetType.habitability[0] + Math.random() * (planetType.habitability[1] - planetType.habitability[0]));
    const metals = Math.floor(planetType.metals[0] + Math.random() * (planetType.metals[1] - planetType.metals[0]));

    // Size affects max population
    const maxPopulation = Math.floor(size * size * 10);

    // Random special resources
    const specials = [];
    if (Math.random() < 0.1) specials.push('Ancient Ruins');
    if (Math.random() < 0.15) specials.push('Rare Elements');
    if (Math.random() < 0.1) specials.push('Anomaly Detected');

    return {
        size: Math.round(size * 10) / 10,
        habitability,
        metals,
        maxPopulation,
        specials
    };
}

/**
 * Creates a planet with procedural texture and attributes
 * @param {Object} config - Planet configuration
 * @returns {THREE.Group} Planet group with mesh and optional rings
 */
export function createPlanet(config) {
    const {
        type,
        orbitRadius,
        orbitSpeed,
        hasRings = false
    } = config;

    const planetType = PLANET_TYPES[type] || PLANET_TYPES.terran;
    const attributes = generatePlanetAttributes(planetType);

    const group = new THREE.Group();

    // Create planet mesh
    const geo = new THREE.SphereGeometry(attributes.size, 32, 32);
    const texture = createPlanetTexture(
        planetType.textureStyle,
        planetType.baseColor,
        planetType.secondaryColor
    );

    const mat = new THREE.MeshStandardMaterial({
        map: texture,
        roughness: 0.6,
        metalness: 0.1,
        emissive: planetType.baseColor,
        emissiveIntensity: 0.15
    });

    const planet = new THREE.Mesh(geo, mat);
    group.add(planet);

    // Add atmospheric glow for habitable planets
    if (attributes.habitability > 30) {
        const glowGeo = new THREE.SphereGeometry(attributes.size * 1.08, 32, 32);
        const glowMat = new THREE.MeshBasicMaterial({
            color: 0x88ccff,
            transparent: true,
            opacity: 0.15 + (attributes.habitability / 500),
            side: THREE.BackSide
        });
        const glow = new THREE.Mesh(glowGeo, glowMat);
        group.add(glow);
    }

    // Add rings if specified
    if (hasRings) {
        const rings = createPlanetRings(
            attributes.size * 1.4,
            attributes.size * 2.2,
            planetType.secondaryColor
        );
        group.add(rings);
    }

    // Store all data in userData
    group.userData = {
        type: type,
        typeName: planetType.name,
        description: planetType.description,
        orbitRadius: orbitRadius,
        orbitSpeed: orbitSpeed,
        orbitAngle: Math.random() * Math.PI * 2,
        rotationSpeed: 0.005 + Math.random() * 0.01,
        ...attributes,
        hasRings
    };

    return group;
}

/**
 * Creates an orbit line for a planet
 * @param {number} radius - Orbit radius
 * @param {number} color - Line color (hex, default: 0x444444)
 * @param {number} opacity - Line opacity (default: 0.3)
 * @returns {THREE.Line} Orbit line
 */
export function createOrbitLine(radius, color = 0x444444, opacity = 0.3) {
    const curve = new THREE.EllipseCurve(
        0, 0,
        radius, radius,
        0, 2 * Math.PI,
        false, 0
    );
    const points = curve.getPoints(64);
    const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
    const lineMat = new THREE.LineBasicMaterial({
        color: color,
        transparent: true,
        opacity: opacity
    });
    const line = new THREE.Line(lineGeo, lineMat);
    line.rotation.x = Math.PI / 2;
    return line;
}

/**
 * Updates planet orbital position and rotation (call in animation loop)
 * @param {THREE.Group} planet - Planet group
 * @param {number} speedMultiplier - Optional speed multiplier (default: 1)
 */
export function updatePlanet(planet, speedMultiplier = 1) {
    const data = planet.userData;
    data.orbitAngle += data.orbitSpeed * speedMultiplier;
    planet.position.x = Math.cos(data.orbitAngle) * data.orbitRadius;
    planet.position.z = Math.sin(data.orbitAngle) * data.orbitRadius;

    // Rotate planet
    if (planet.children[0]) {
        planet.children[0].rotation.y += data.rotationSpeed * speedMultiplier;
    }
}

/**
 * Picks a random planet type based on star characteristics
 * @param {string} starClass - Star classification (O, B, A, F, G, K, M)
 * @param {number} orbitIndex - Position in system (0 = closest to star)
 * @returns {string} Planet type key
 */
export function pickPlanetType(starClass, orbitIndex) {
    // Inner orbits more likely to be hot/barren
    // Outer orbits more likely to be cold/gas giants

    const innerTypes = ['lava', 'barren', 'desert'];
    const middleTypes = ['terran', 'desert', 'jungle', 'ocean'];
    const outerTypes = ['ice', 'gasGiant', 'iceGiant', 'barren'];

    let typePool;
    if (orbitIndex <= 1) {
        typePool = innerTypes;
    } else if (orbitIndex <= 3) {
        typePool = middleTypes;
    } else {
        typePool = outerTypes;
    }

    // Hotter stars shift toward more barren inner planets
    if (['O', 'B', 'A'].includes(starClass) && orbitIndex <= 2) {
        typePool = ['lava', 'barren', 'desert'];
    }

    return typePool[Math.floor(Math.random() * typePool.length)];
}
