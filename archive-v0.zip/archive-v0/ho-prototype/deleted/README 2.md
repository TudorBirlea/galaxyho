# Spaceward Ho! - Galaxy Navigator

A 3D space exploration game built with THREE.js featuring procedurally generated galaxies and solar systems.

## Project Structure

```
spaceward-ho/
├── index.html                    # Main game - Galaxy navigator with system view
├── standalone/
│   └── system-view.html         # Standalone solar system viewer
├── src/
│   ├── core/
│   │   ├── scene.js            # Scene, renderer, camera, lighting setup
│   │   └── controls.js         # OrbitControls configuration
│   ├── objects/
│   │   ├── sun.js              # Sun creation with animated shaders
│   │   ├── planet.js           # Planet generation with procedural textures
│   │   └── star.js             # Galaxy star sprites and classifications
│   └── utils/                   # (Reserved for future utilities)
├── archive/
│   ├── spaceward-ho-v2.html    # Original monolithic game
│   ├── system.html             # Original system view
│   ├── system1.html            # System view backup
│   ├── system-backup.html      # Another system backup
│   └── suns.html               # Sun shader experiments
└── test-modules.html           # Module test suite

```

## Features

### Galaxy View
- 120 procedurally generated stars with realistic spectral classifications (O, B, A, F, G, K, M)
- Star colors and sizes based on real stellar properties
- Interactive hover effects showing star information
- 8000-point starfield background
- Atmospheric fog and bloom effects

### System View
- Detailed animated sun with plasma-like surface shader
- 3-7 procedurally generated planets per system
- Realistic planet textures with surface features
- Orbital mechanics with varying speeds
- Multiple lighting sources for realistic shading
- Smooth transitions between galaxy and system views

## Technologies

- **THREE.js r160** - 3D rendering engine
- **WebGL** - Hardware-accelerated graphics
- **GLSL Shaders** - Custom sun surface animations
- **ES6 Modules** - Modular code architecture

## Running the Project

The project uses ES6 modules and requires a local web server to run properly.

### Option 1: Python HTTP Server
```bash
# From the project directory
python3 -m http.server 8000
```
Then open: `http://localhost:8000/index.html`

### Option 2: Node.js HTTP Server
```bash
npx http-server -p 8000
```
Then open: `http://localhost:8000/index.html`

### Option 3: VS Code Live Server
- Install the "Live Server" extension
- Right-click on `index.html` and select "Open with Live Server"

## Usage

### Galaxy View
- **Mouse Move**: Hover over stars to see information
- **Click**: Click on a star to enter its system view
- **Mouse Drag**: Rotate the camera
- **Scroll**: Zoom in/out

### System View
- **Mouse Drag**: Rotate around the system
- **Scroll**: Zoom in/out
- **Back Button**: Return to galaxy view

## Module Documentation

### Core Modules

#### `src/core/scene.js`
- `createScene(backgroundColor)` - Creates THREE.js scene
- `createRenderer(options)` - Creates WebGL renderer
- `createCamera(options)` - Creates perspective camera
- `createComposer(renderer, scene, camera, bloomOptions)` - Sets up post-processing
- `createLighting(scene, options)` - Adds lights to scene
- `setupResizeHandler(camera, renderer, composer)` - Handles window resize

#### `src/core/controls.js`
- `createOrbitControls(camera, domElement, options)` - Creates camera controls

### Object Modules

#### `src/objects/sun.js`
- `createSimpleSun(radius, starColor)` - Simple 3-layer noise shader sun
- `createDetailedSun(radius, starColor)` - Detailed 4-layer noise shader sun
- `updateSun(sunGroup, time, enablePulse)` - Animates sun in render loop

#### `src/objects/planet.js`
- `createPlanetTexture(color, resolution)` - Generates procedural planet texture
- `createPlanet(config)` - Creates planet mesh with glow effect
- `createOrbitLine(radius, color, opacity)` - Creates orbital path line
- `updatePlanet(planet)` - Updates planet orbital position

#### `src/objects/star.js`
- `createStarTexture()` - Generates radial gradient for star sprites
- `pickStarClass()` - Randomly selects star classification
- `createStarSprite(config, texture, position, name)` - Creates 3-layer star sprite
- `generateGalaxyPositions(count, minRadius, maxRadius)` - Generates star positions
- `updateStarAnimation(starNodes, time)` - Animates flickering stars

## Star Classifications

The game uses realistic stellar classifications:

| Class | Color | Temperature | Probability |
|-------|-------|-------------|-------------|
| O-Class | Blue | 30,000K+ | 0.00003% |
| B-Class | Blue-White | 10,000-30,000K | 0.13% |
| A-Class | White | 7,500-10,000K | 0.6% |
| F-Class | Yellow-White | 6,000-7,500K | 3% |
| G-Class | Yellow | 5,200-6,000K | 7.6% |
| K-Class | Orange | 3,700-5,200K | 12.1% |
| M-Class | Red | 2,400-3,700K | 76.45% |

## Performance Notes

- The simple sun shader (`createSimpleSun`) uses 3 noise layers and is more performant
- The detailed sun shader (`createDetailedSun`) uses 4 noise layers for better visual quality
- Planet textures are generated at 512x512 resolution for good quality/performance balance
- Bloom post-processing adds visual quality but has a performance cost

## Development History

This project was refactored from a monolithic HTML file into a modular architecture:
1. Created separate modules for reusable components
2. Extracted core functionality (scene, camera, controls)
3. Isolated object creation logic (sun, planets, stars)
4. Maintained backward compatibility with original functionality

Original files are preserved in the `archive/` folder for reference.

## Future Enhancements

Potential areas for expansion:
- Planet interaction and information cards
- Multiple sun systems (binary/trinary stars)
- Asteroid belts and rings
- Save/load galaxy state
- Procedural planet names
- Resource management gameplay
- Ship navigation between systems
