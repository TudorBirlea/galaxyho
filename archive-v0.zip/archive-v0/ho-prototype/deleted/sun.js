import * as THREE from 'three';

/**
 * Creates a simple animated sun with plasma-like surface effect
 * Uses 3-layer noise shader for performance
 * @param {number} radius - Sun radius (default: 6)
 * @param {number} starColor - Optional color for the sun (hex)
 * @returns {THREE.Group} Sun group with shader material and corona layers
 */
export function createSimpleSun(radius = 6, starColor = 0xFFDD77) {
    const sunGroup = new THREE.Group();
    const geometry = new THREE.SphereGeometry(radius, 64, 64);

    const material = new THREE.ShaderMaterial({
        uniforms: { time: { value: 0 } },
        vertexShader: `
            varying vec2 vUv;
            void main() {
                vUv = uv;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `,
        fragmentShader: `
            uniform float time;
            varying vec2 vUv;

            float random(vec2 st) {
                return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
            }

            float noise(vec2 st) {
                vec2 i = floor(st);
                vec2 f = fract(st);
                float a = random(i);
                float b = random(i + vec2(1.0, 0.0));
                float c = random(i + vec2(0.0, 1.0));
                float d = random(i + vec2(1.0, 1.0));
                vec2 u = f * f * (3.0 - 2.0 * f);
                return mix(a, b, u.x) + (c - a)* u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
            }

            void main() {
                vec2 uv = vUv * 8.0;
                float n = noise(uv + time * 0.5);
                n += noise(uv * 2.0 - time * 0.3) * 0.5;
                n += noise(uv * 4.0 + time * 0.7) * 0.25;

                vec3 color1 = vec3(1.0, 0.95, 0.8);
                vec3 color2 = vec3(1.0, 0.85, 0.5);
                vec3 finalColor = mix(color1, color2, n);
                finalColor *= 1.3;

                gl_FragColor = vec4(finalColor, 1.0);
            }
        `
    });

    const sun = new THREE.Mesh(geometry, material);
    sunGroup.add(sun);
    sunGroup.userData.material = material;

    const coronaLayers = [
        { radius: radius * 1.17, opacity: 0.5, color: 0xFFEE88 },
        { radius: radius * 1.42, opacity: 0.35, color: 0xFFDD77 },
        { radius: radius * 1.67, opacity: 0.2, color: 0xFFCC66 }
    ];

    coronaLayers.forEach(layer => {
        const geo = new THREE.SphereGeometry(layer.radius, 32, 32);
        const mat = new THREE.MeshBasicMaterial({
            color: layer.color,
            transparent: true,
            opacity: layer.opacity,
            side: THREE.BackSide,
            blending: THREE.AdditiveBlending
        });
        sunGroup.add(new THREE.Mesh(geo, mat));
    });

    return sunGroup;
}

/**
 * Creates a detailed animated sun with 4-layer noise shader
 * More detailed surface but slightly more expensive to render
 * @param {number} radius - Sun radius (default: 8)
 * @param {number} starColor - Optional color for the sun (hex)
 * @returns {THREE.Group} Sun group with detailed shader and multiple corona layers
 */
export function createDetailedSun(radius = 8, starColor = 0xFFDD77) {
    const sunGroup = new THREE.Group();
    const sunGeometry = new THREE.SphereGeometry(radius, 64, 64);

    const sunMaterial = new THREE.ShaderMaterial({
        uniforms: {
            time: { value: 0 },
            sunColor: { value: new THREE.Color(starColor) }
        },
        vertexShader: `
            varying vec2 vUv;
            varying vec3 vNormal;
            void main() {
                vUv = uv;
                vNormal = normalize(normalMatrix * normal);
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `,
        fragmentShader: `
            uniform float time;
            uniform vec3 sunColor;
            varying vec2 vUv;
            varying vec3 vNormal;

            float random(vec2 st) {
                return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
            }

            float noise(vec2 st) {
                vec2 i = floor(st);
                vec2 f = fract(st);
                float a = random(i);
                float b = random(i + vec2(1.0, 0.0));
                float c = random(i + vec2(0.0, 1.0));
                float d = random(i + vec2(1.0, 1.0));
                vec2 u = f * f * (3.0 - 2.0 * f);
                return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
            }

            void main() {
                // Create animated surface detail with 4 layers
                vec2 uv = vUv * 10.0;
                float n = noise(uv + time * 0.3);
                n += noise(uv * 2.0 - time * 0.2) * 0.5;
                n += noise(uv * 4.0 + time * 0.4) * 0.25;
                n += noise(uv * 8.0 - time * 0.15) * 0.125;

                // Bright yellow-white base with texture variation
                vec3 baseColor = vec3(1.0, 0.95, 0.85);
                vec3 detailColor = sunColor;
                vec3 finalColor = mix(detailColor, baseColor, n * 0.4 + 0.6);

                // Add brightness boost
                finalColor *= 1.4;

                gl_FragColor = vec4(finalColor, 1.0);
            }
        `
    });

    const sun = new THREE.Mesh(sunGeometry, sunMaterial);
    sunGroup.add(sun);
    sunGroup.userData.sunMaterial = sunMaterial;
    sunGroup.userData.sun = sun;

    // Strong corona layers with 6 layers
    const coronaLayers = [
        { radius: radius * 1.04, opacity: 0.5, color: 0xFFFFDD },
        { radius: radius * 1.15, opacity: 0.4, color: 0xFFEE99 },
        { radius: radius * 1.31, opacity: 0.3, color: 0xFFDD77 },
        { radius: radius * 1.5, opacity: 0.2, color: 0xFFCC66 },
        { radius: radius * 1.75, opacity: 0.12, color: 0xFFBB55 },
        { radius: radius * 2.13, opacity: 0.06, color: 0xFFAA44 }
    ];

    coronaLayers.forEach((layer, i) => {
        const coronaGeometry = new THREE.SphereGeometry(layer.radius, 32, 32);
        const coronaMaterial = new THREE.MeshBasicMaterial({
            color: layer.color,
            transparent: true,
            opacity: layer.opacity,
            side: THREE.BackSide,
            blending: THREE.AdditiveBlending
        });
        const corona = new THREE.Mesh(coronaGeometry, coronaMaterial);
        corona.userData.layerIndex = i;
        corona.userData.baseOpacity = layer.opacity;
        corona.userData.pulseOffset = i * 0.6;
        sunGroup.add(corona);
    });

    return sunGroup;
}

/**
 * Updates sun animation (call in animation loop)
 * @param {THREE.Group} sunGroup - Sun group returned from createSun functions
 * @param {number} time - Current time in seconds
 * @param {boolean} enablePulse - Enable corona pulsing effect (default: false)
 */
export function updateSun(sunGroup, time, enablePulse = false) {
    // Update shader time
    if (sunGroup.userData.material) {
        sunGroup.userData.material.uniforms.time.value = time;
    }
    if (sunGroup.userData.sunMaterial) {
        sunGroup.userData.sunMaterial.uniforms.time.value = time;
    }

    // Rotate sun
    sunGroup.rotation.y += 0.002;

    // Rotate sun surface if available
    if (sunGroup.userData.sun) {
        sunGroup.userData.sun.rotation.y += 0.001;
    }

    // Optional corona pulsing
    if (enablePulse) {
        sunGroup.children.forEach((child) => {
            if (child.userData.layerIndex !== undefined) {
                const baseOpacity = child.userData.baseOpacity;
                const pulse = Math.sin(time * 0.5 + child.userData.pulseOffset) * 0.02;
                child.material.opacity = Math.max(0, baseOpacity + pulse);
            }
        });
    }
}
