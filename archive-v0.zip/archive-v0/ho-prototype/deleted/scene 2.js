import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

/**
 * Creates and configures a THREE.js scene with standard settings
 * @param {number} backgroundColor - Background color (hex, default: 0x0f0f20)
 * @returns {THREE.Scene}
 */
export function createScene(backgroundColor = 0x0f0f20) {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(backgroundColor);
    return scene;
}

/**
 * Creates and configures renderer with antialias and pixel ratio
 * @param {Object} options - Renderer configuration
 * @param {boolean} options.antialias - Enable antialiasing (default: true)
 * @param {number} options.maxPixelRatio - Maximum pixel ratio (default: 2)
 * @returns {THREE.WebGLRenderer}
 */
export function createRenderer(options = {}) {
    const { antialias = true, maxPixelRatio = 2 } = options;

    const renderer = new THREE.WebGLRenderer({ antialias });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, maxPixelRatio));

    return renderer;
}

/**
 * Creates a perspective camera with standard settings
 * @param {Object} options - Camera configuration
 * @param {number} options.fov - Field of view (default: 45)
 * @param {number} options.near - Near clipping plane (default: 0.1)
 * @param {number} options.far - Far clipping plane (default: 1000)
 * @param {THREE.Vector3} options.position - Camera position (default: 60, 40, 60)
 * @returns {THREE.PerspectiveCamera}
 */
export function createCamera(options = {}) {
    const {
        fov = 45,
        near = 0.1,
        far = 1000,
        position = new THREE.Vector3(60, 40, 60)
    } = options;

    const camera = new THREE.PerspectiveCamera(
        fov,
        window.innerWidth / window.innerHeight,
        near,
        far
    );
    camera.position.copy(position);

    return camera;
}

/**
 * Creates an effect composer with bloom post-processing
 * @param {THREE.WebGLRenderer} renderer - WebGL renderer
 * @param {THREE.Scene} scene - Scene to render
 * @param {THREE.Camera} camera - Camera to use
 * @param {Object} bloomOptions - Bloom pass configuration
 * @param {number} bloomOptions.strength - Bloom strength (default: 2.0)
 * @param {number} bloomOptions.radius - Bloom radius (default: 0.8)
 * @param {number} bloomOptions.threshold - Bloom threshold (default: 0.1)
 * @returns {EffectComposer}
 */
export function createComposer(renderer, scene, camera, bloomOptions = {}) {
    const {
        strength = 2.0,
        radius = 0.8,
        threshold = 0.1
    } = bloomOptions;

    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));

    const bloom = new UnrealBloomPass(
        new THREE.Vector2(window.innerWidth, window.innerHeight),
        strength,
        radius,
        threshold
    );
    composer.addPass(bloom);

    return composer;
}

/**
 * Creates standard lighting setup for space scenes
 * @param {THREE.Scene} scene - Scene to add lights to
 * @param {Object} options - Lighting configuration
 * @param {boolean} options.ambient - Add ambient light (default: true)
 * @param {boolean} options.point - Add point light at center (default: true)
 * @param {boolean} options.directional - Add directional lights (default: false)
 * @returns {Array<THREE.Light>} Array of created lights
 */
export function createLighting(scene, options = {}) {
    const {
        ambient = true,
        point = true,
        directional = false
    } = options;

    const lights = [];

    if (ambient) {
        const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
        scene.add(ambientLight);
        lights.push(ambientLight);
    }

    if (point) {
        const pointLight = new THREE.PointLight(0xFFFFEE, 5, 150);
        pointLight.position.set(0, 0, 0);
        scene.add(pointLight);
        lights.push(pointLight);
    }

    if (directional) {
        const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.6);
        dirLight1.position.set(15, 10, 10);
        scene.add(dirLight1);
        lights.push(dirLight1);

        const dirLight2 = new THREE.DirectionalLight(0xffffdd, 0.4);
        dirLight2.position.set(-10, 8, -10);
        scene.add(dirLight2);
        lights.push(dirLight2);

        const topLight = new THREE.DirectionalLight(0xffffff, 0.5);
        topLight.position.set(0, 20, 0);
        scene.add(topLight);
        lights.push(topLight);
    }

    return lights;
}

/**
 * Sets up window resize handler
 * @param {THREE.Camera} camera - Camera to update
 * @param {THREE.WebGLRenderer} renderer - Renderer to update
 * @param {EffectComposer} composer - Composer to update (optional)
 */
export function setupResizeHandler(camera, renderer, composer = null) {
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);

        if (composer) {
            composer.setSize(window.innerWidth, window.innerHeight);
        }
    });
}
