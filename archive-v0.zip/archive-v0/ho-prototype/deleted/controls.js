import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

/**
 * Creates and configures OrbitControls
 * @param {THREE.Camera} camera - Camera to control
 * @param {HTMLElement} domElement - DOM element for event listeners (usually renderer.domElement)
 * @param {Object} options - Control configuration
 * @param {boolean} options.enableDamping - Enable damping/inertia (default: true)
 * @param {boolean} options.autoRotate - Enable auto rotation (default: false)
 * @param {number} options.autoRotateSpeed - Auto rotation speed (default: 0.3)
 * @param {THREE.Vector3} options.target - Look-at target (optional)
 * @returns {OrbitControls}
 */
export function createOrbitControls(camera, domElement, options = {}) {
    const {
        enableDamping = true,
        autoRotate = false,
        autoRotateSpeed = 0.3,
        target = null
    } = options;

    const controls = new OrbitControls(camera, domElement);
    controls.enableDamping = enableDamping;
    controls.autoRotate = autoRotate;
    controls.autoRotateSpeed = autoRotateSpeed;

    if (target) {
        controls.target.copy(target);
        controls.update();
    }

    return controls;
}
