import * as THREE from 'three';

/**
 * Creates a starfield background for system view
 * @param {number} count - Number of background stars (default: 2000)
 * @param {number} radius - Distance from center (default: 300)
 * @returns {THREE.Points} Starfield particle system
 */
export function createStarfield(count = 2000, radius = 300) {
    const geometry = new THREE.BufferGeometry();
    const vertices = [];
    const colors = [];

    for (let i = 0; i < count; i++) {
        // Random spherical distribution
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos(2 * Math.random() - 1);
        const r = radius + Math.random() * 200;

        vertices.push(
            r * Math.sin(phi) * Math.cos(theta),
            r * Math.sin(phi) * Math.sin(theta),
            r * Math.cos(phi)
        );

        // Vary star colors slightly (white to slight blue/yellow tint)
        const tint = Math.random();
        if (tint < 0.7) {
            // White stars
            colors.push(1, 1, 1);
        } else if (tint < 0.85) {
            // Slight blue tint
            colors.push(0.8, 0.9, 1);
        } else {
            // Slight yellow tint
            colors.push(1, 0.95, 0.8);
        }
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
        size: 1.2,
        sizeAttenuation: true,
        vertexColors: true,
        transparent: true,
        opacity: 0.8
    });

    return new THREE.Points(geometry, material);
}

/**
 * Creates a nebula-like background effect using planes with gradient textures
 * @param {number} count - Number of nebula layers (default: 3)
 * @returns {THREE.Group} Group containing nebula planes
 */
export function createNebula(count = 3) {
    const group = new THREE.Group();

    const nebulaColors = [
        { r: 0.3, g: 0.1, b: 0.4 },  // Purple
        { r: 0.1, g: 0.3, b: 0.5 },  // Blue
        { r: 0.4, g: 0.2, b: 0.3 }   // Pink
    ];

    for (let i = 0; i < count; i++) {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 512;
        const ctx = canvas.getContext('2d');

        // Clear canvas to fully transparent
        ctx.clearRect(0, 0, 512, 512);

        const color = nebulaColors[i % nebulaColors.length];

        // Create radial gradient with proper alpha channel
        const gradient = ctx.createRadialGradient(256, 256, 0, 256, 256, 256);
        gradient.addColorStop(0, `rgba(${Math.floor(color.r * 255)}, ${Math.floor(color.g * 255)}, ${Math.floor(color.b * 255)}, 0.12)`);
        gradient.addColorStop(0.4, `rgba(${Math.floor(color.r * 255)}, ${Math.floor(color.g * 255)}, ${Math.floor(color.b * 255)}, 0.06)`);
        gradient.addColorStop(0.7, `rgba(${Math.floor(color.r * 255)}, ${Math.floor(color.g * 255)}, ${Math.floor(color.b * 255)}, 0.02)`);
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 512, 512);

        const texture = new THREE.CanvasTexture(canvas);
        texture.needsUpdate = true;

        const material = new THREE.MeshBasicMaterial({
            map: texture,
            transparent: true,
            opacity: 0.5,
            side: THREE.FrontSide,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            depthTest: true
        });

        const size = 500 + Math.random() * 300;
        const geometry = new THREE.PlaneGeometry(size, size);
        const plane = new THREE.Mesh(geometry, material);

        // Random position further away
        const distance = 280 + Math.random() * 50;
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;

        plane.position.set(
            distance * Math.sin(phi) * Math.cos(theta),
            distance * Math.sin(phi) * Math.sin(theta),
            distance * Math.cos(phi)
        );

        plane.lookAt(0, 0, 0);
        plane.rotation.z = Math.random() * Math.PI * 2;

        group.add(plane);
    }

    return group;
}

/**
 * Animates starfield with slow rotation
 * @param {THREE.Points} starfield - Starfield to animate
 * @param {number} speed - Rotation speed (default: 0.0001)
 */
export function animateStarfield(starfield, speed = 0.0001) {
    starfield.rotation.y += speed;
    starfield.rotation.x += speed * 0.5;
}
