import * as THREE from 'three';

/**
 * Star classification data for galaxy view
 * Based on spectral types with realistic colors and properties
 */
export const starClasses = [
    { n: 'O-Class', c: 0x9bb0ff, s: [3, 6], t: '30,000K+', m: 'High', prob: 0.00003 },
    { n: 'B-Class', c: 0xaabfff, s: [2.5, 5], t: '10,000-30,000K', m: 'Medium-High', prob: 0.13 },
    { n: 'A-Class', c: 0xcad7ff, s: [2, 4], t: '7,500-10,000K', m: 'Medium', prob: 0.6 },
    { n: 'F-Class', c: 0xf8f7ff, s: [1.8, 3.5], t: '6,000-7,500K', m: 'Medium', prob: 3 },
    { n: 'G-Class', c: 0xfff4ea, s: [1.5, 3], t: '5,200-6,000K', m: 'Medium', prob: 7.6 },
    { n: 'K-Class', c: 0xffd2a1, s: [1.3, 2.5], t: '3,700-5,200K', m: 'Low-Medium', prob: 12.1 },
    { n: 'M-Class', c: 0xffcc6f, s: [1, 2], t: '2,400-3,700K', m: 'Low', prob: 76.45 }
];

/**
 * Creates a radial gradient texture for star sprites
 * @returns {THREE.Texture}
 */
export function createStarTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    const gradient = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
    gradient.addColorStop(0, 'rgba(255,255,255,1)');
    gradient.addColorStop(0.2, 'rgba(255,255,255,0.9)');
    gradient.addColorStop(0.4, 'rgba(255,255,255,0.5)');
    gradient.addColorStop(0.7, 'rgba(255,255,255,0.1)');
    gradient.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 128, 128);
    return new THREE.CanvasTexture(canvas);
}

/**
 * Picks a random star class based on probability distribution
 * @returns {Object} Star class configuration
 */
export function pickStarClass() {
    const rand = Math.random() * 100;
    let cumulative = 0;
    for (const cls of starClasses) {
        cumulative += cls.prob;
        if (rand <= cumulative) return cls;
    }
    return starClasses[starClasses.length - 1];
}

/**
 * Creates a star sprite for galaxy view
 * Three-layer sprite: outer glow, colored halo, bright white core
 * @param {Object} config - Star class configuration
 * @param {THREE.Texture} starTexture - Pre-created star texture
 * @param {THREE.Vector3} position - Star position
 * @param {string} name - Star system name
 * @returns {THREE.Group} Star sprite group
 */
export function createStarSprite(config, starTexture, position, name) {
    const group = new THREE.Group();

    // Random size within range with additional variability multiplier
    const baseSize = config.s[0] + Math.random() * (config.s[1] - config.s[0]);
    const sizeVariability = 0.7 + Math.random() * 0.6; // 0.7x to 1.3x multiplier
    const size = baseSize * sizeVariability;

    // Bright white core
    const core = new THREE.Sprite(new THREE.SpriteMaterial({
        map: starTexture,
        color: 0xffffff,
        blending: THREE.AdditiveBlending
    }));
    core.scale.set(size * 0.3, size * 0.3, 1);

    // Colored halo (main glow)
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
        map: starTexture,
        color: config.c,
        blending: THREE.AdditiveBlending,
        transparent: true,
        opacity: 0.7
    }));
    halo.scale.set(size, size, 1);

    // Outer diffuse glow for extra depth
    const outerGlow = new THREE.Sprite(new THREE.SpriteMaterial({
        map: starTexture,
        color: config.c,
        blending: THREE.AdditiveBlending,
        transparent: true,
        opacity: 0.25
    }));
    outerGlow.scale.set(size * 1.8, size * 1.8, 1);

    group.add(outerGlow);
    group.add(halo);
    group.add(core);

    group.position.copy(position);

    group.userData = {
        name: name,
        class: config.n,
        temp: config.t,
        metal: config.m,
        color: config.c,
        baseScale: size,
        planets: [] // Will be populated when system is clicked
    };

    return group;
}

/**
 * Generates multiple random star positions in galaxy
 * @param {number} count - Number of stars to generate
 * @param {number} minRadius - Minimum distance from center (default: 60)
 * @param {number} maxRadius - Maximum distance from center (default: 310)
 * @param {number} verticalSpread - Vertical position spread (default: 60)
 * @returns {Array<THREE.Vector3>} Array of star positions
 */
export function generateGalaxyPositions(count, minRadius = 60, maxRadius = 310, verticalSpread = 60) {
    const positions = [];
    for (let i = 0; i < count; i++) {
        const r = minRadius + Math.random() * (maxRadius - minRadius);
        const t = Math.random() * Math.PI * 2;
        const pos = new THREE.Vector3(
            Math.cos(t) * r,
            (Math.random() - 0.5) * verticalSpread,
            Math.sin(t) * r
        );
        positions.push(pos);
    }
    return positions;
}

/**
 * Updates star animation (call in animation loop for galaxy view)
 * Applies flickering effect to stars
 * @param {Array<THREE.Group>} starNodes - Array of star groups
 * @param {number} time - Current time in seconds
 */
export function updateStarAnimation(starNodes, time) {
    starNodes.forEach((s, i) => {
        const baseSize = s.userData.baseScale;
        const noise = 1.0 + Math.sin(time * 4 + i) * 0.08;
        // children[0] = outer glow, children[1] = halo, children[2] = core
        s.children[0].material.opacity = 0.2 + Math.sin(time * 2.5 + i) * 0.08; // Outer glow
        s.children[1].material.opacity = 0.6 + Math.sin(time * 3 + i) * 0.15;   // Main halo
        s.children[2].scale.setScalar(baseSize * 0.3 * noise);                  // Core flicker
    });
}
