import * as THREE from 'three';

/**
 * Creates a procedurally generated planet texture
 * @param {number} color - Base color in hex format
 * @param {number} resolution - Texture resolution (default: 512)
 * @returns {THREE.CanvasTexture}
 */
export function createPlanetTexture(color, resolution = 512) {
    const canvas = document.createElement('canvas');
    canvas.width = resolution;
    canvas.height = resolution;
    const ctx = canvas.getContext('2d');

    const center = resolution / 2;

    // Base color with stronger gradient for 3D effect
    const gradient = ctx.createRadialGradient(center, center, 0, center, center, center);
    const colorR = (color >> 16) & 0xff;
    const colorG = (color >> 8) & 0xff;
    const colorB = color & 0xff;

    gradient.addColorStop(0, `rgb(${Math.min(255, colorR * 1.5)}, ${Math.min(255, colorG * 1.5)}, ${Math.min(255, colorB * 1.5)})`);
    gradient.addColorStop(0.4, `rgb(${Math.min(255, colorR * 1.2)}, ${Math.min(255, colorG * 1.2)}, ${Math.min(255, colorB * 1.2)})`);
    gradient.addColorStop(0.7, `rgb(${colorR}, ${colorG}, ${colorB})`);
    gradient.addColorStop(1, `rgb(${colorR * 0.5}, ${colorG * 0.5}, ${colorB * 0.5})`);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, resolution, resolution);

    // Add more detailed surface features
    const numFeatures = Math.floor(resolution / 6.4); // 80 features for 512px
    for (let i = 0; i < numFeatures; i++) {
        const x = Math.random() * resolution;
        const y = Math.random() * resolution;
        const size = 8 + Math.random() * 40;
        const brightness = Math.random() > 0.5 ? 255 : 0;
        const alpha = 0.15 + Math.random() * 0.25;
        ctx.fillStyle = `rgba(${brightness}, ${brightness}, ${brightness}, ${alpha})`;
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fill();
    }

    // Add some color variation bands
    const numBands = Math.floor(resolution / 25.6); // 20 bands for 512px
    for (let i = 0; i < numBands; i++) {
        const y = Math.random() * resolution;
        const height = 5 + Math.random() * 20;
        const alpha = 0.08 + Math.random() * 0.12;
        ctx.fillStyle = `rgba(${colorR}, ${colorG}, ${colorB}, ${alpha})`;
        ctx.fillRect(0, y, resolution, height);
    }

    return new THREE.CanvasTexture(canvas);
}

/**
 * Creates a planet with procedural texture and glow effect
 * @param {Object} config - Planet configuration
 * @param {number} config.radius - Planet radius
 * @param {number} config.color - Planet base color (hex)
 * @param {number} config.orbitRadius - Orbital distance from sun
 * @param {number} config.orbitSpeed - Orbital speed
 * @param {number} config.emissiveIntensity - Self-illumination strength (default: 0.5)
 * @param {number} config.glowOpacity - Glow effect opacity (default: 0.4)
 * @returns {THREE.Mesh} Planet mesh with texture and glow
 */
export function createPlanet(config) {
    const {
        radius,
        color,
        orbitRadius,
        orbitSpeed,
        emissiveIntensity = 0.5,
        glowOpacity = 0.4
    } = config;

    const geo = new THREE.SphereGeometry(radius, 32, 32);
    const texture = createPlanetTexture(color);
    const mat = new THREE.MeshStandardMaterial({
        map: texture,
        roughness: 0.5,
        metalness: 0.2,
        emissive: color,
        emissiveIntensity: emissiveIntensity
    });
    const planet = new THREE.Mesh(geo, mat);

    planet.userData = {
        orbitRadius: orbitRadius,
        orbitSpeed: orbitSpeed,
        orbitAngle: Math.random() * Math.PI * 2
    };

    // Add glow effect to each planet for depth
    const glowGeometry = new THREE.SphereGeometry(radius * 1.15, 32, 32);
    const glowMaterial = new THREE.MeshBasicMaterial({
        color: color,
        transparent: true,
        opacity: glowOpacity,
        side: THREE.BackSide
    });
    const glow = new THREE.Mesh(glowGeometry, glowMaterial);
    planet.add(glow);

    return planet;
}

/**
 * Creates an orbit line for a planet
 * @param {number} radius - Orbit radius
 * @param {number} color - Line color (hex, default: 0x444444)
 * @param {number} opacity - Line opacity (default: 0.3)
 * @returns {THREE.Line} Orbit line
 */
export function createOrbitLine(radius, color = 0x444444, opacity = 0.3) {
    const curve = new THREE.EllipseCurve(
        0, 0,
        radius, radius,
        0, 2 * Math.PI,
        false, 0
    );
    const points = curve.getPoints(64);
    const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
    const lineMat = new THREE.LineBasicMaterial({
        color: color,
        transparent: true,
        opacity: opacity
    });
    const line = new THREE.Line(lineGeo, lineMat);
    line.rotation.x = Math.PI / 2;
    return line;
}

/**
 * Updates planet orbital position (call in animation loop)
 * @param {THREE.Mesh} planet - Planet mesh
 */
export function updatePlanet(planet) {
    const data = planet.userData;
    data.orbitAngle += data.orbitSpeed;
    planet.position.x = Math.cos(data.orbitAngle) * data.orbitRadius;
    planet.position.z = Math.sin(data.orbitAngle) * data.orbitRadius;
    planet.rotation.y += 0.01;
}

/**
 * Creates a planet from a planet type definition
 * Used by the main game for procedural planet generation
 * @param {Object} planetType - Planet type config with name, baseColor, emissive, size range
 * @param {number} orbitRadius - Orbital distance
 * @param {number} orbitSpeed - Orbital speed
 * @returns {THREE.Mesh} Planet mesh
 */
export function createPlanetFromType(planetType, orbitRadius, orbitSpeed) {
    const size = planetType.size[0] + Math.random() * (planetType.size[1] - planetType.size[0]);

    return createPlanet({
        radius: size,
        color: planetType.baseColor,
        orbitRadius: orbitRadius,
        orbitSpeed: orbitSpeed,
        emissiveIntensity: 0.5,
        glowOpacity: 0.4
    });
}
